﻿using System;

namespace Exercise3
{


    // C# program to count squares  between a and b

    class GFG
    {

        // Function to print all the perfect
        // squares from the given range
        static void perfectSquares(int l, int r)
        {

            // For every element from the range
            for (int i = l; i <= r; i++)
            {

                // If current element is
                // a perfect square
                if (Math.Sqrt(i) == (int)Math.Sqrt(i))
                    Console.Write(i + " ");
            }
        }

        // Driver code
        public static void Main(String[] args)
        {
            int l = 2, r = 24;
            perfectSquares(l, r);
        }
    }
}
