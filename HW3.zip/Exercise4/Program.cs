﻿using System;

namespace Exercise4
{
    class StudentAndTeacherTest
    {
        static void Main(string[] args) // Example of program usage
        {
            Person person = new Person("Joel");
            person.Greet();


            Student student = new Student("Jesse");
            student.SetAge(20);
            student.Greet();
            student.ShowAge();


            Teacher teacher = new Teacher("Walter");
            teacher.SetAge(30);
            teacher.Greet();
            teacher.Explain();


            Console.ReadKey();
        }
    }


    class Person
    {
        protected string name;
        protected int age;


        public Person(string name)
        {
            this.name = name;
        }


        public virtual void Greet() // Method for greeting
        {
            Console.WriteLine("Person " + name + " says hello.");
        }




        public void SetAge(int n) // Method for setting age
        {
            this.age = n;
        }
    }

    class Student : Person
    {
        public Student(string name) : base(name)
        {


        }


        public void ShowAge()
        {
            Console.WriteLine("My age is " + age + " years old.");
        }


        public void GoToClasses()
        {
            Console.WriteLine("I'm going to class.");
        }


        public override void Greet() // Overridden method for greeting in class Student
        {
            Console.WriteLine("Student " + name + " says hello.");
        }
    }


    class Teacher : Person
    {
        public Teacher(string name) : base(name)
        {


        }


        public void Explain()
        {
            Console.WriteLine("Explanation begins.");
        }
        public override void Greet() // Overridden method for greeting in class Teacher
        {
            Console.WriteLine("Teacher " + name + " says hello.");
        }
    }
}
